package kz.iitu.spring.payrollsystem;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PayrollSystemApplication {

    public static void main(String[] args) {
        SpringApplication.run(PayrollSystemApplication.class, args);
    }

}

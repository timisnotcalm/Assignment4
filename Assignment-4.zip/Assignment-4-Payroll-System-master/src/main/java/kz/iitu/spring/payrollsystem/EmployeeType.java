package kz.iitu.spring.payrollsystem;

public enum EmployeeType {
    SALARIED,HOURLY, COMMISSION,SALARIED_COMMISSION
}

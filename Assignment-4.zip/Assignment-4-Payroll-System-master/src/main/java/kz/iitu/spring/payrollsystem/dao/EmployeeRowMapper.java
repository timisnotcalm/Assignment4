package kz.iitu.spring.payrollsystem.dao;

public class EmployeeRowMapper {
}

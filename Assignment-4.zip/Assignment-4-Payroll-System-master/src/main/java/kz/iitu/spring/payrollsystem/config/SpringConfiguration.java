package kz.iitu.spring.payrollsystem.config;

import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

@Configuration
@ComponentScan(basePackages = "kz.iitu.spring.payrollsystem")
public class SpringConfiguration {
}

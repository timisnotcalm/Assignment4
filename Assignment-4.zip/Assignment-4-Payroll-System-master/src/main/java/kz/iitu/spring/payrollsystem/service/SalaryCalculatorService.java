package kz.iitu.spring.payrollsystem.service;

public class SalaryCalculatorService {

}
